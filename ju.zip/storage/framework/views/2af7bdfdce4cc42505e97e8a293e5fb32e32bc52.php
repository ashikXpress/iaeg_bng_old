<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="iq-card">
                <div class="iq-card-header d-flex justify-content-between">
                    <div class="iq-header-title">
                        <h4 class="card-title">About Text</h4>
                    </div>
                </div>
                <div class="iq-card-body">
                    <?php if($message = Session::get('success')): ?>

                        <div class="alert alert-success">

                            <p><?php echo e($message); ?></p>

                        </div>

                    <?php endif; ?>

                        <form action="<?php echo e(route('about.update.submit')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <input type="text" value="<?php echo e($about->title); ?>" name="title" placeholder="Enter Title" class="form-control">
                            </div>

                            <div class="form-group">

                                <textarea style="line-height: 22px;height: 350px;" placeholder="Enter Description" class="form-control" name="description" id="description" rows="5"><?php echo e($about->description); ?></textarea>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">Update</button>
                                <a href="<?php echo e(route('about.update')); ?>" class="btn iq-bg-danger">cancel</a>

                            </div>
                        </form>

                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="iq-card">
                <div class="iq-card-header d-flex justify-content-between">
                    <div class="iq-header-title">
                        <h4 class="card-title">About Image
                            <button type="button" class="btn btn-primary btnView">Add New</button>
                        </h4>

                    </div>
                </div>
                <div class="iq-card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Image</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $about_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><img width="150" src="<?php echo e(asset($item->image)); ?>" alt="Image"></td>
                                <td>
                                    <button data-id="<?php echo e($item->id); ?>" type="button" class="btn btn-primary updateModal">Update</button>
                                    <a class="btn btn-danger" href="#" onclick="return checkDelete('<?php echo e(route('about.image.delete',$item->id)); ?>')">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <?php echo e($about_images->links()); ?>

                            </tfoot>
                        </table>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade bd-example-modal-lg" id="about_image" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New About Image</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('about.image.submit')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <div class="custom-file">
                                <input type="file" name="image" class="custom-file-input" id="customFile">
                                <label class="custom-file-label" for="customFile">Choose Image</label>
                            </div>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Save</button>

                        </div>
                    </form>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade bd-example-modal-lg" id="about_image_update" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Update About Image</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('about.image.update')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="update_image_id" id="update_image_id">
                        <div class="form-group">
                            <div class="custom-file">
                                <input required type="file" name="image" class="custom-file-input" id="customFile">
                                <label class="custom-file-label" for="customFile">Choose Image</label>
                            </div>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Update</button>

                        </div>
                    </form>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('additionalJS'); ?>
    <script>
        $(function() {
            $('.btnView').click(function () {
                $('#about_image').modal('show');
            });
            $('.updateModal').click(function () {
                $('#about_image_update').modal('show');

                var id = $(this).data('id');
                $('#update_image_id').val(id);


            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP-7.4.2\htdocs\ju\resources\views/admin/about_text.blade.php ENDPATH**/ ?>