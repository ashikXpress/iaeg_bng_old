<?php $__env->startSection('content'); ?>
    <!-- Start Breadcrumbs -->
    <section class="breadcrumbs overlay">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2>About Us</h2>
                    <ul class="bread-list">
                        <li><a href="<?php echo e(route('home')); ?>">Home<i class="fa fa-angle-right"></i></a></li>
                        <li class="active"><a href="#">about</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!--/ End Breadcrumbs -->

    <!-- About US -->
    <section class="about-us section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-12">
                        <div class="single-event events single" style="padding: 30px 0;">
                            <div class="event-gallery">
                                <?php $__currentLoopData = $about->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="single-gallery">
                                        <img src="<?php echo e(asset($item->image)); ?>" alt="#">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                    </div>
                </div>
                <div class="col-lg-6 col-12">
                    <div class="about-text">
                        <h2><?php echo e($about->title); ?></h2>
                        <p class="text-justify"><?php echo e($about->description); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ End About US -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP-7.4.2\htdocs\ju\resources\views/frontend/about.blade.php ENDPATH**/ ?>