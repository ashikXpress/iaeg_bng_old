<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="iq-card">
                <div class="iq-card-header d-flex justify-content-between">
                    <div class="iq-header-title">
                        <h4 class="card-title">Social Links</h4>
                    </div>
                </div>
                <div class="iq-card-body">
                    <?php if($message = Session::get('success')): ?>

                        <div class="alert alert-success">

                            <p><?php echo e($message); ?></p>

                        </div>

                    <?php endif; ?>

                        <form action="<?php echo e(route('social.links.update',$links->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <input type="text" value="<?php echo e($links->facebook); ?>" name="facebook" placeholder="Facebook Links" class="form-control">
                                <span class="text text-danger"><?php echo e($errors->first('facebook')); ?></span>
                            </div>
                            <div class="form-group">
                                <input type="text" value="<?php echo e($links->twitter); ?>" name="twitter" placeholder="Twitter Links" class="form-control">
                                <span class="text text-danger"><?php echo e($errors->first('twitter')); ?></span>
                            </div>
                            <div class="form-group">
                                <input type="text" value="<?php echo e($links->youtube); ?>" name="youtube" placeholder="Youtube Links" class="form-control">
                                <span class="text text-danger"><?php echo e($errors->first('youtube')); ?></span>
                            </div>
                            <div class="form-group">
                                <input type="text" value="<?php echo e($links->linkend); ?>" name="linkend" placeholder="Linkend Links" class="form-control">
                                <span class="text text-danger"><?php echo e($errors->first('linkend')); ?></span>
                            </div>
                            <div class="form-group">
                                <input type="text" value="<?php echo e($links->google_plus); ?>" name="google_plus" placeholder="Google Plus Links" class="form-control">
                                <span class="text text-danger"><?php echo e($errors->first('google_plus')); ?></span>
                            </div>
                            <div class="form-group">
                                <input type="text" value="<?php echo e($links->instragram); ?>" name="instragram" placeholder="Instragram Links" class="form-control">
                                <span class="text text-danger"><?php echo e($errors->first('instrsgram')); ?></span>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">Update</button>
                                <a href="<?php echo e(route('dashboard')); ?>" class="btn iq-bg-danger">cancel</a>

                            </div>
                          </form>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ju\resources\views/admin/social_links.blade.php ENDPATH**/ ?>