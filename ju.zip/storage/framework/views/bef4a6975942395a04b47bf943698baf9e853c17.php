

<?php $__env->startSection('content'); ?>

    <div class="row">
       <?php echo $__env->make('layouts.assets.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="iq-card">
                <div class="iq-card-header d-flex justify-content-between">
                    <div class="iq-header-title">
                        <div class="card-title">
                            <div class="pull-left">
                                <h4>All Approved Event List</h4>
                            </div>

                        </div>

                    </div>
                </div>
                <div class="iq-card-body">
                    <table class="table table-bordered">
                        <thead>
                        <tr>

                            <th>No</th>
                            <th>Event Name</th>
                            <th>Event Type</th>
                            <th>Category</th>
                            <th>Participate Name</th>
                            <th>Event Document</th>
                            <th>Membership</th>
                            <th>Mail Send</th>


                        </tr>
                        </thead>
                        <tbody>
                            <?php
                                $sl = 1;
                            ?>

                            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $event->members()->wherePivot('payment_status', 1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <?php if($loop->first): ?>
                                            <td rowspan="<?php echo e(count($event->members)); ?>"><?php echo e($sl++); ?></td>
                                            <td rowspan="<?php echo e(count($event->members)); ?>"><?php echo e($event->name); ?></td>
                                            <td rowspan="<?php echo e(count($event->members)); ?>"><?php echo e($event->categoryName->name); ?></td>
                                        <?php endif; ?>

                                        <td><?php echo e($member->pivot->exhibition_category); ?></td>
                                        <td width="25%"><a href="#" onclick="get_member('<?php echo e($member->id); ?>')"><?php echo e($member->first_name.' '.$member->middle_name.' '.$member->last_name); ?></a></td>
                                        <td width="10%">
                                            <?php if($event->categoryName->id==1): ?>
                                                <button type="button" class="btn btn-primary" onclick="get_view('<?php echo e($member->id); ?>','<?php echo e($event->id); ?>')">Info</button>

                                            <?php endif; ?>
                                        </td>
                                        <td width="10%"><?php echo e($member->memberType->name); ?></td>
                                        <td width="10%">
                                            <button type="button" class="btn btn-primary btnView" data-id="<?php echo e($member->id); ?>">Mail</button>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                        <?php echo e($events->links()); ?>

                        </tfoot>
                    </table>


                </div>
            </div>
        </div>
    </div>

    <div class="modal fade bd-example-modal-lg" id="member_mail" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Mail Send</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('event.participate.reply.mail')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <div class="modal-body">
                        <textarea id="member_message" name="message" required placeholder="Type Message" class="form-control"></textarea>
                    <input type="hidden" id="member_id" name="member_id">
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Send</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>

                </div>
             </form>
            </div>
        </div>
    </div>
    <div class="modal fade bd-example-modal-lg" id="documentModal" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Technical Event Details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>Paper Name</th>
                            <th>Author Affiliation</th>
                            <th>Corresponding Email</th>
                            <th>Abstract Document</th>
                            <th>Presentation ppt</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>

                            <td id="paper_title"></td>
                            <td id="author_affiliation"></td>
                            <td id="corresponding_email"></td>
                            <td><a target="_blank" id="abstract_doc_file" href="#">doc download</a></td>
                            <td><a target="_blank" id="presentation_ppt_file" href="#">ppt download</a></td>

                        </tr>
                        </tbody>

                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade bd-example-modal-lg" id="memberDetails" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Mobile Number</th>
                            <th>Photo</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>

                            <td id="member_email"></td>
                            <td id="contact_address"></td>
                            <td id="member_mobile"></td>
                            <td><img width="100" id="member_img" src="" alt="img"></td>

                        </tr>
                        </tbody>

                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('additionalJS'); ?>
    <script>
        $(function() {
            $('.btnView').click(function () {
                var id = $(this).data('id');

                $('#member_id').val(id);
                $('#member_message').val('');

                $('#member_mail').modal('show');
            });
        });
        function get_view(member_id,event_id) {


            var member_id=member_id;
            var event_id=event_id;

            $.ajax({
                method: "GET",
                url: "<?php echo e(route('event.document.details')); ?>",
                data: {member_id: member_id,event_id:event_id}
            }).done(function (data) {
                $('#documentModal').modal('show');


                $('#paper_title').html(data.paper_title);
                $('#author_affiliation').html(data.author_affiliation);
                $('#corresponding_email').html(data.corresponding_email);

                $('#abstract_doc_file').attr('href',data.abstract_doc_file);
                $('#presentation_ppt_file').attr('href',data.presentation_ppt_file);


            });
        }


function get_member(member_id) {
    var member_id=member_id;


    $.ajax({
        method: "GET",
        url: "<?php echo e(route('event.member.details')); ?>",
        data: {member_id: member_id}
    }).done(function (data) {
        $('#memberDetails').modal('show');

        $('#member_email').html(data.email);
        $('#member_mobile').html(data.mobile_number);
        $('#contact_address').html(data.contact_address);

        $('#member_img').attr('src',data.profile_image);


    });
}


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/iaegbng/public_html/resources/views/admin/event_join/approved_event.blade.php ENDPATH**/ ?>