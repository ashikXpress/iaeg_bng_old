<footer class="bg-white iq-footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 text-center">
                © Copyright <?php echo e(date('Y')); ?> IAEG_BNG - BANGLADESH NATIONAL GROUP. All Rights Reserved | <a style="font-size: 18px" href="http://2aitbd.com/" target="_blank"> Design and Developed by 2A IT</a>.
            </div>
        </div>
    </div>
</footer>
<?php /**PATH D:\xampp\htdocs\ju\resources\views/layouts/assets/footer.blade.php ENDPATH**/ ?>