<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="iq-card">
                <div class="iq-card-header d-flex justify-content-between">
                    <div class="iq-header-title">
                        <div class="card-title">
                            <div class="pull-left">
                                <h4>All Approved Member</h4>
                            </div>

                        </div>

                    </div>
                </div>
                <div class="iq-card-body">
                    <?php if($message = Session::get('success')): ?>

                        <div class="alert alert-success">

                            <p><?php echo e($message); ?></p>

                        </div>

                    <?php endif; ?>
                    <table class="table">
                        <thead>
                        <tr>

                            <th>No</th>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Membership</th>


                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td><?php echo e($loop->iteration); ?></td>

                                <td><img style="width: 80px;height: 80px;object-fit: contain" src="<?php echo e(asset($member->profile_image)); ?>" alt=""></td>

                                <td><?php echo e($member->first_name.' '.$member->middle_name.' '.$member->last_name); ?></td>
                                <td><?php echo e($member->memberType->name); ?></td>






                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                    <?php echo e($members->links()); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP-7.4.2\htdocs\ju\resources\views/admin/member/approved_member.blade.php ENDPATH**/ ?>