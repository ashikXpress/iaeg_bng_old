<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php echo $__env->make('layouts.assets.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-lg-12">
        <div class="card iq-mb-3">
            <div class="row no-gutters">
                <div class="col-md-5">
                    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <?php
                                $i=0;
                            ?>
                            <?php $__currentLoopData = $event->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item <?php echo e(($i==0) ? 'active' : ''); ?>">
                                <img class="d-block w-100" src="<?php echo e(asset($img->image)); ?>" alt="First slide">
                            </div>
                                <?php $i++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="card-body">
                        <p class="card-text pull-right"><small class="text-muted">Posted <?php echo e($event->created_at->diffForHumans()); ?></small></p>

                        <h4 class="card-title"><?php echo e($event->name); ?></h4>
                        <p class="mb-0"><strong>Start Date</strong> <i class="fa fa-calendar"></i> <?php echo e(date('d M Y',strtotime($event->start_date))); ?> <?php echo e(date('h:m A',strtotime($event->start_date))); ?></p>
                        <p class="mb-0"><strong>End Date</strong> <i class="fa fa-calendar"></i> <?php echo e(date('d M Y',strtotime($event->end_date))); ?> <?php echo e(date('h:m A',strtotime($event->end_date))); ?></p>
                        <h5>Venue: <?php echo e($event->venue); ?></h5>
                        <h6>Session: <?php echo e($event->session); ?></h6>
                        <p class="card-text"><?php echo e($event->description); ?></p>
                        <?php if($event->event_category_id==1): ?>
                            <a href="<?php echo e(route('member.event.technical.join',$event->id)); ?>" class="btn btn-primary">Join</a>
                        <?php elseif($event->event_category_id==2): ?>
                            <a href="<?php echo e(route('member.event.exhibition.join',$event->id)); ?>" class="btn btn-primary">Join</a>
                        <?php elseif($event->event_category_id==3): ?>
                            <a href="<?php echo e(route('member.event.field.join',$event->id)); ?>" class="btn btn-primary">Join</a>

                        <?php endif; ?>
                        <p class="card-text"><small class="text-muted">Posted <?php echo e($event->created_at->diffForHumans()); ?></small></p>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ju\resources\views/member/event_details.blade.php ENDPATH**/ ?>