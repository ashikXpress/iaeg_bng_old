<?php $__env->startSection('content'); ?>

    <div class="row">
       <?php echo $__env->make('layouts.assets.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="iq-card">
                <div class="iq-card-header d-flex justify-content-between">
                    <div class="iq-header-title">
                        <div class="card-title">
                            <div class="pull-left">
                                <h4>All Approved Event List</h4>
                            </div>

                        </div>

                    </div>
                </div>
                <div class="iq-card-body">
                    <table class="table table-bordered">
                        <thead>
                        <tr>

                            <th>No</th>
                            <th>Event Name</th>
                            <th>Category</th>
                            <th>Participate Name</th>
                            <th>Membership</th>
                            <th>Mail Send</th>


                        </tr>
                        </thead>
                        <tbody>
                            <?php
                                $sl = 1;
                            ?>

                            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $event->members()->wherePivot('payment_status', 1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <?php if($loop->first): ?>
                                            <td rowspan="<?php echo e(count($event->members)); ?>"><?php echo e($sl++); ?></td>
                                            <td rowspan="<?php echo e(count($event->members)); ?>"><?php echo e($event->name); ?></td>
                                        <?php endif; ?>

                                        <td><?php echo e($member->pivot->exhibition_category); ?></td>
                                        <td width="25%"><?php echo e($member->first_name.' '.$member->middle_name.' '.$member->last_name); ?></td>
                                        <td width="10%"><?php echo e($member->memberType->name); ?></td>
                                        <td width="10%">
                                            <button type="button" class="btn btn-primary btnView" data-id="<?php echo e($member->id); ?>">Mail</button>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                        <?php echo e($events->links()); ?>

                        </tfoot>
                    </table>


                </div>
            </div>
        </div>
    </div>

    <div class="modal fade bd-example-modal-lg" id="member_mail" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Mail Send</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('event.participate.reply.mail')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                <div class="modal-body">
                        <textarea id="member_message" name="message" required placeholder="Type Message" class="form-control"></textarea>
                    <input type="hidden" id="member_id" name="member_id">
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Send</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>

                </div>
             </form>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('additionalJS'); ?>
    <script>
        $(function() {
            $('.btnView').click(function () {
                var id = $(this).data('id');

                $('#member_id').val(id);
                $('#member_message').val('');

                $('#member_mail').modal('show');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP-7.4.2\htdocs\ju\resources\views/admin/event_join/approved_event.blade.php ENDPATH**/ ?>