<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo e(config('app.name')); ?>  <?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('layouts.assets.__style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('additionalCSS'); ?>

</head>
<body>

<!-- loader Start -->
<div id="loading">
    <div id="loading-center">

    </div>
</div>
<!-- loader END -->
<!-- Wrapper Start -->
<div class="wrapper">
    <!-- Sidebar  -->
    <?php echo $__env->make('layouts.assets.side_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Page Content  -->
    <div id="content-page" class="content-page">
        <!-- TOP Nav Bar -->
    <?php echo $__env->make('layouts.assets.top_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- TOP Nav Bar END -->
        <div class="container-fluid">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <!-- Footer -->
            <?php echo $__env->make('layouts.assets.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Footer END -->
    </div>
</div>
<!-- Wrapper END -->
<?php echo $__env->make('layouts.assets.__script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('additionalJS'); ?>
</body>
</html>
<?php /**PATH D:\PHP-7.4.2\htdocs\ju\resources\views/layouts/admin.blade.php ENDPATH**/ ?>