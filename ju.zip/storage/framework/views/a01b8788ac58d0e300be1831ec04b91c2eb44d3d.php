<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\xampp\htdocs\ju\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>