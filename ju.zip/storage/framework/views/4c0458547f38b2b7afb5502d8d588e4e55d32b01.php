<?php $__env->startSection('additionalCSS'); ?>
    <style>
        .iq-email-content .iq-email-date {

            width: 120px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 mail-box-detail">
            <div class="iq-card">
                <div class="iq-card-body p-0">
                    <div class="">
                        <div class="iq-email-to-list p-3">
                            <div class="d-flex justify-content-between">
                              <h3>All Contact Mail</h3>
                            </div>
                            <?php if($message = Session::get('success')): ?>

                                <div class="alert alert-success">

                                    <p><?php echo e($message); ?></p>

                                </div>

                            <?php endif; ?>
                        </div>
                        <div class="iq-email-listbox">
                            <div class="tab-content">
                                <div class="tab-pane fade show active" id="mail-inbox" role="tabpanel">
                                    <ul class="iq-email-sender-list">
                                        <?php $__currentLoopData = $mails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="iq-unread">
                                            <div class="d-flex align-self-center">
                                                <div class="iq-email-sender-info">
                                                    <?php if($mail->read_at==1): ?>
                                                        <a href="<?php echo e(route('contact.mail.view',$mail->id)); ?>"><span class="fa fa-envelope-open-o iq-star-toggle text-warning"></span></a>
                                                    <?php else: ?>
                                                        <a href="<?php echo e(route('contact.mail.view',$mail->id)); ?>"><span class="fa fa-envelope-o iq-star-toggle text-primary"></span></a>

                                                    <?php endif; ?>

                                                        <a href="<?php echo e(route('contact.mail.view',$mail->id)); ?>" class="iq-email-title"><?php echo e($mail->name); ?></a>
                                                </div>

                                                <div class="iq-email-content">
                                                    <a href="<?php echo e(route('contact.mail.view',$mail->id)); ?>" class="iq-email-subject"><?php echo e($mail->subject.'('.$mail->email.')'); ?></a>
                                                    <div class="iq-email-date"><?php echo e($mail->created_at->diffForHumans()); ?></div>
                                                </div>
                                                <ul class="iq-social-media">
                                                    <li><a onclick="return checkDelete('<?php echo e(route('contact.mail.delete',$mail->id)); ?>;')" href="#"><i class="fa fa-trash"></i></a></li>
                                                    <li><a href="<?php echo e(route('contact.mail.view',$mail->id)); ?>"><i class="fa fa-eye"></i></a></li>
                                                    <li><a href="<?php echo e(route('contact.mail.reply',$mail->id)); ?>"><i class="fa fa-reply"></i></a></li>
                                                </ul>
                                            </div>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </ul>
                                </div>
                            </div>

                        </div>

                    </div>

                </div>
                <div class="card card-footer" style="background: #fff;border-bottom-left-radius: 50%;border-bottom-right-radius: 50%;border-top: 1px solid #eef0f4;">
                    <div class="pull-right">
                        <?php echo e($mails->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP-7.4.2\htdocs\ju\resources\views/admin/contact/all.blade.php ENDPATH**/ ?>