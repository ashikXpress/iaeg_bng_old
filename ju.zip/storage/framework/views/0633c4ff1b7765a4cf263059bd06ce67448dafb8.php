<?php $__env->startSection('additionalCSS'); ?>
    <style>
        a.btn-download {
            background: #00b16a;
            color: #fff;
            padding: 6px 16px;
            margin: 5px 1px;
            display: inline-block;
            border-radius: 5px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="fb-root"></div>
    <!-- Start Breadcrumbs -->
    <section class="breadcrumbs overlay">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2>News Details</h2>
                    <ul class="bread-list">
                        <li><a href="<?php echo e(route('home')); ?>">Home<i class="fa fa-angle-right"></i></a></li>
                        <li class="active"><a href="#">News Details</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!--/ End Breadcrumbs -->

    <!-- Events -->
    <section class="events single section">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-12">
                    <div class="single-event">
                        <?php if($news->category_id==1): ?>
                        <img width="100%" height="auto" src="<?php echo e(asset($news->image_or_file)); ?>" alt="#">
                        <?php endif; ?>
                        <div class="event-content">
                            <h4><?php echo e($news->title); ?> </h4>
                            <span> <i class="fa fa-user"></i> Post by: <span style="color: #00b16a"><?php echo e($news->userName->name); ?></span></span>
                            <?php if($news->category_id==2): ?>
                                <div class="course-meta">
                                   <span class="span"><a target="_blank"  class="btn-download" href="<?php echo e(asset($news->image_or_file)); ?>"><i class="fa fa-cloud-download"></i> File Download</a></span>
                                </div>

                            <?php endif; ?>
                            <div class="meta">
                                <span><i class="fa fa-calendar"></i> <?php echo e(date('d M Y',strtotime($news->upload_date))); ?></span>
                            </div>
                            <p><?php echo e($news->description); ?></p>
                            <div class="fb-comments" data-href="<?php echo e(url()->current()); ?>" data-numposts="10"></div>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-12">
                    <div class="learnedu-sidebar">
                        <!-- Categories -->
                        <div class="single-widget categories">
                            <h3 class="title">Archive</h3>
                            <ul>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Education Tips<span>2020</span></a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Education Tips<span>2021</span></a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Education Tips<span>2023</span></a></li>

                            </ul>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ End Events -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('additionalJS'); ?>
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v5.0"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP-7.4.2\htdocs\ju\resources\views/frontend/single_news.blade.php ENDPATH**/ ?>