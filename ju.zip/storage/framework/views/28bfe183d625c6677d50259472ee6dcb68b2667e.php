<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php echo $__env->make('layouts.assets.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
   <div class="row">
       <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="col-sm-4">
           <div class="card iq-mb-3">
               <img src="<?php echo e(asset($event->images[0]->image)); ?>" class="card-img-top" alt="#">
               <div class="card-body">
                   <h5 class="card-title"><?php echo e($event->name); ?></h5>
                   <p class="mb-0"><strong>Start Date</strong> <i class="fa fa-calendar"></i> <?php echo e(date('d M Y',strtotime($event->start_date))); ?> <?php echo e(date('h:m A',strtotime($event->start_date))); ?></p>
                   <p class="mb-0"><strong>End Date</strong> <i class="fa fa-calendar"></i> <?php echo e(date('d M Y',strtotime($event->end_date))); ?> <?php echo e(date('h:m A',strtotime($event->end_date))); ?></p>
                   <h5>Venue: <?php echo e($event->venue); ?></h5>
                   <h6>Session: <?php echo e($event->session); ?></h6>
                   <a href="<?php echo e(route('member.event.details',$event->id)); ?>"><strong>read more</strong></a>
                   <p class="card-text mb-0"><small class="text-muted"><?php echo e($event->created_at->diffForHumans()); ?></small></p>
                   <?php
                       $member= Auth::guard('member')->user();
                   ?>
                   <?php if(!$member->events->contains($event->id)): ?>
                   <a href="<?php echo e(route('member.event.field.join',$event->id)); ?>" class="btn btn-primary btn-block">Join</a>
                   <?php else: ?>
                       <button class="btn btn-success btn-block">Already You Participated</button>

                   <?php endif; ?>
               </div>
           </div>
       </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP-7.4.2\htdocs\ju\resources\views/member/field_event_list.blade.php ENDPATH**/ ?>