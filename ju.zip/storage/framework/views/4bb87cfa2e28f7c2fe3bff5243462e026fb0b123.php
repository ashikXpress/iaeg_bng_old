<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="iq-card">
                <div class="iq-card-header d-flex justify-content-between">
                    <div class="iq-header-title">
                        <div class="card-title">
                            <div class="pull-left">
                                <h4>All News Letter</h4>
                            </div>
                            <div class="pull-right">

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-create')): ?>

                                    <a class="btn btn-primary" href="<?php echo e(route('news.letter.form')); ?>"> Create New News Letter</a>

                                <?php endif; ?>

                            </div>
                        </div>

                    </div>
                </div>
                <div class="iq-card-body">
                    <?php if($message = Session::get('success')): ?>

                        <div class="alert alert-success">

                            <p><?php echo e($message); ?></p>

                        </div>

                    <?php endif; ?>
                    <table class="table">
                        <thead>
                        <tr>

                            <th>No</th>
                            <th>File</th>
                            <th>Name</th>
                            <th>Posted by</th>
                            <th>Date</th>
                            <th width="280px">Action</th>

                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td><?php echo e($loop->iteration); ?></td>

                                <td><a class="btn btn-success" target="_blank" href="<?php echo e(asset($item->image_or_file)); ?>">File Download</a></td>

                                <td><?php echo e($item->title); ?></td>
                                <td><?php echo e($item->userName->name); ?></td>
                                <td><?php echo e(date('D M Y',strtotime($item->upload_date))); ?></td>
                                <td>
                                    <a class="btn btn-info" href="<?php echo e(route('news.letter.edit', $item->id)); ?>">Edit</a>
                                    <a href="#" onclick="return checkDelete('<?php echo e(route('news.letter.delete',$item->id)); ?>;')" class="btn btn-danger">Delete</a>


                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                    <?php echo e($news->links()); ?>

                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/iaegbng/public_html/resources/views/admin/news/all_letter_news.blade.php ENDPATH**/ ?>