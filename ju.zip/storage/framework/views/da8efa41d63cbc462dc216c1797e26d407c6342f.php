<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="iq-card">
                <div class="iq-card-header d-flex justify-content-between">
                    <div class="iq-header-title">
                        <div class="card-title">
                            <h4 class="pull-left">All Gallery</h4>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-create')): ?>
                                <a class="btn btn-primary pull-right" href="<?php echo e(route('gallery.form')); ?>"> Create New Gallery</a><br>
                            <?php endif; ?>
                        </div>


                    </div>
                </div>
                <div class="iq-card-body">
                    <?php if($message = Session::get('success')): ?>

                        <div class="alert alert-success">

                            <p><?php echo e($message); ?></p>

                        </div>

                    <?php endif; ?>
                    <table class="table">
                        <thead>
                        <tr>

                            <th>No</th>

                            <th>Image</th>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Action</th>

                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td><?php echo e($loop->iteration); ?></td>

                                <td><img width="150px" src="<?php echo e($gallery->image); ?>" alt=""></td>

                                <td><?php echo e($gallery->title); ?></td>
                                <td><?php echo e($gallery->categoryName->name); ?></td>
                                <td>
                                    <a class="btn btn-info" href="<?php echo e(route('gallery.edit', $gallery->id)); ?>">Edit</a>
                                    <a href="#" onclick="return checkDelete('<?php echo e(route('gallery.delete',$gallery->id)); ?>;')" class="btn btn-danger">Delete</a>


                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                    <?php echo e($galleries->links()); ?>

                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP-7.4.2\htdocs\ju\resources\views/admin/gallery/all.blade.php ENDPATH**/ ?>