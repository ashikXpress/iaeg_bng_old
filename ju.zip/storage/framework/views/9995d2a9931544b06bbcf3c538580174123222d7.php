<div class="iq-sidebar">
    <div class="iq-sidebar-logo d-flex justify-content-between">
        <a href="<?php echo e(route('dashboard')); ?>">

            <span>IAEG_BNG</span>
        </a>
        <div class="iq-menu-bt-sidebar">
            <div class="iq-menu-bt align-self-center">
                <div class="wrapper-menu">
                    <div class="main-circle"><i class="ri-more-fill"></i></div>
                    <div class="hover-circle"><i class="ri-more-2-fill"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div id="sidebar-scrollbar">
        <nav class="iq-sidebar-menu">
            <ul class="iq-menu">

                <li class="<?php echo e(Route::currentRouteName() === 'dashboard' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('dashboard')); ?>" class="iq-waves-effect"><i class="ri-hospital-fill"></i><span>Dashboard</span></a>
                </li>


                <?php
                    $subMenu = ['users.index','users.create','users.edit','roles.index','roles.create','roles.edit'];
                ?>

                <li class="<?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'menu-open' : ''); ?>">

                    <a href="javascript:void(0);" class="iq-waves-effect"><i class="fa fa-user-plus"></i><span>Administrator</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>
                    <ul class="iq-submenu <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'menu-open' : ''); ?>">

                        <li><a href="<?php echo e(route('users.index')); ?>" class="<?php echo e(Route::currentRouteName() === 'users.index' ? 'active' : ''); ?>"><i class="fa fa-user"></i>Manage Admin</a></li>
                       <li><a href="<?php echo e(route('roles.index')); ?>" class="<?php echo e(Route::currentRouteName() === 'roles.index' ? 'active' : ''); ?>"><i class="fa fa-universal-access"></i>Manage Role & Permission</a></li>
                    </ul>
                </li>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('about')): ?>
                <li class="<?php echo e(Route::currentRouteName() === 'about.update' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('about.update')); ?>" class="iq-waves-effect"><i class="fa fa-user-plus"></i><span>About Us</span></a>
                </li>
                <?php endif; ?>


                <?php
                    $subMenu = ['all.slider','slider.form','slider.edit'];
                ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('slider-list')): ?>
                <li class="<?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'menu-open' : ''); ?>">

                    <a href="javascript:void(0);" class="iq-waves-effect"><i class="fa fa-user-plus"></i><span>Slider</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>
                    <ul class="iq-submenu <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'menu-open' : ''); ?>">


                        <li><a href="<?php echo e(route('all.slider')); ?>" class="<?php echo e(Route::currentRouteName() === 'all.slider' ? 'active' : ''); ?>"><i class="fa fa-universal-access"></i>Manage Slider</a></li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php
                    $subMenu = ['all.gallery','gallery.form','gallery.edit','gallery.category.form'];
                ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('gallery-list')): ?>
                <li class="<?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'menu-open' : ''); ?>">

                    <a href="javascript:void(0);" class="iq-waves-effect"><i class="fa fa-user-plus"></i><span>Gallery</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>
                    <ul class="iq-submenu <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'menu-open' : ''); ?>">

                        <li><a href="<?php echo e(route('gallery.category.form')); ?>" class="<?php echo e(Route::currentRouteName() === 'gallery.category.form' ? 'active' : ''); ?>"><i class="fa fa-user"></i>Add Category</a></li>
                        <li><a href="<?php echo e(route('all.gallery')); ?>" class="<?php echo e(Route::currentRouteName() === 'all.gallery' ? 'active' : ''); ?>"><i class="fa fa-user"></i>Manage Gallery</a></li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php
                    $subMenu = ['all.basic.news','basic.news.form','basic.news.edit','all.news.letter','news.letter.form','news.letter.edit'];
                ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('news-list')): ?>
                <li class="<?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'menu-open' : ''); ?>">

                    <a href="javascript:void(0);" class="iq-waves-effect"><i class="fa fa-user-plus"></i><span>News</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>
                    <ul class="iq-submenu <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'menu-open' : ''); ?>">

                        <li><a href="<?php echo e(route('all.basic.news')); ?>" class="<?php echo e(Route::currentRouteName() === 'all.basic.news' ? 'active' : ''); ?>"><i class="fa fa-user"></i>Manage Basic News </a></li>
                        <li><a href="<?php echo e(route('all.news.letter')); ?>" class="<?php echo e(Route::currentRouteName() === 'all.news.letter' ? 'active' : ''); ?>"><i class="fa fa-universal-access"></i>Manage News Letter</a></li>
                    </ul>
                </li>
                <?php endif; ?>



                <?php
                    $subMenu = ['all.event','event.form','event.edit'];
                ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('event-list')): ?>
                <li class="<?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'menu-open' : ''); ?>">

                    <a href="javascript:void(0);" class="iq-waves-effect"><i class="fa fa-user-plus"></i><span>Event</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>
                    <ul class="iq-submenu <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'menu-open' : ''); ?>">

                        <li><a href="<?php echo e(route('all.event')); ?>" class="<?php echo e(Route::currentRouteName() === 'all.event' ? 'active' : ''); ?>"><i class="fa fa-universal-access"></i>Manage Event</a></li>
                    </ul>
                </li>
                <?php endif; ?>
                <?php
                    $subMenu = ['event.join.unapproved.list','approved.event.participate.list'];
                ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('event-approved-list','event-unapproved-list')): ?>
                <li class="<?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'menu-open' : ''); ?>">

                    <a href="javascript:void(0);" class="iq-waves-effect"><i class="fa fa-user-plus"></i><span>Event Join Manage</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>
                    <ul class="iq-submenu <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'menu-open' : ''); ?>">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('event-approved-list')): ?>
                        <li><a href="<?php echo e(route('approved.event.participate.list')); ?>" class="<?php echo e(Route::currentRouteName() === 'approved.event.participate.list' ? 'active' : ''); ?>"><i class="fa fa-universal-access"></i>Approved List </a></li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('event-unapproved-list')): ?>
                        <li><a href="<?php echo e(route('event.join.unapproved.list')); ?>" class="<?php echo e(Route::currentRouteName() === 'event.join.unapproved.list' ? 'active' : ''); ?>"><i class="fa fa-universal-access"></i>Unapproved List <h4 class="ml-5 badge badge-danger">New  <?php echo e(($unapproved_event_count)?$unapproved_event_count: '0'); ?></h4></a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>



                <?php
                    $subMenu = ['add.member.form','unapproved.member.list','approved.member.list'];
                ?>

 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('member-approved-list','member-unapproved-list')): ?>
                <li class="<?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'menu-open' : ''); ?>">

                    <a href="javascript:void(0);" class="iq-waves-effect"><i class="fa fa-user-plus"></i><span>Member Manage</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>
                    <ul class="iq-submenu <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'menu-open' : ''); ?>">

                            <li><a href="<?php echo e(route('add.member.form')); ?>" class="<?php echo e(Route::currentRouteName() === 'add.member.form' ? 'active' : ''); ?>"><i class="fa fa-universal-access"></i>Add new member</a></li>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('member-approved-list')): ?>
                        <li><a href="<?php echo e(route('approved.member.list')); ?>" class="<?php echo e(Route::currentRouteName() === 'approved.member.list' ? 'active' : ''); ?>"><i class="fa fa-universal-access"></i>Approved</a></li>
                       <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('member-unapproved-list')): ?>
                        <li><a href="<?php echo e(route('unapproved.member.list')); ?>" class="<?php echo e(Route::currentRouteName() === 'unapproved.member.list' ? 'active' : ''); ?>"><i class="fa fa-universal-access"></i>Unapproved <h4 class="ml-5 badge badge-danger"> New  <?php echo e(($unapproved_count)?$unapproved_count: '0'); ?></h4></a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>



                <?php
                    $subMenu = ['all.contact.mail','contact.mail.view','contact.mail.reply'];
                ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('contact-mail-manage')): ?>
                <li class="<?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'menu-open' : ''); ?>">

                    <a href="javascript:void(0);" class="iq-waves-effect"><i class="fa fa-user-plus"></i><span>Contact Mail</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>
                    <ul class="iq-submenu <?php echo e(in_array(Route::currentRouteName(), $subMenu) ? 'menu-open' : ''); ?>">

                        <li><a href="<?php echo e(route('all.contact.mail')); ?>" class="<?php echo e(Route::currentRouteName() === 'all.contact.mail' ? 'active' : ''); ?>"><i class="fa fa-universal-access"></i>Mail Manage</a></li>
                    </ul>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('social-links')): ?>
                <li class="<?php echo e(Route::currentRouteName() === 'social.links' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('social.links')); ?>" class="iq-waves-effect"><i class="fa fa-user-plus"></i><span>Social Links</span></a>
                </li>
                <?php endif; ?>

            </ul>
        </nav>
        <div class="p-3"></div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\ju\resources\views/layouts/assets/side_navbar.blade.php ENDPATH**/ ?>