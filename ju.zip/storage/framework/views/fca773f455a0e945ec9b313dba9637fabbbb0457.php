<?php $__env->startSection('content'); ?>
    <!-- Start Breadcrumbs -->
    <section class="breadcrumbs overlay">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2>Member Register</h2>
                    <ul class="bread-list">
                        <li><a href="<?php echo e(route('home')); ?>">Home<i class="fa fa-angle-right"></i></a></li>
                        <li class="active"><a href="#">Register</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!--/ End Breadcrumbs -->
    <section id="contact" class="contact section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title">
                        <h2><span>Registeration</span> Information</h2>
                        <p>Mauris at varius orci. Vestibulum interdum felis eu nisl pulvinar, quis ultricies nibh. Sed ultricies ante vitae laoreet sagittis. In pellentesque viverra purus. Sed risus est, molestie nec hendrerit hendrerit, sollicitudin nec ante.  </p>
                    </div>
                </div>
            </div>
            <div class="contact-head">

            </div>
            <div class="contact-bottom">
                <div class="row">
                    <div class="col-md-8 offset-2">
                        <?php if(session()->has('success')): ?>
                            <h5 class="alert alert-success"><?php echo e(session()->get('success')); ?></h5>
                        <?php endif; ?>
                        <div class="form-head">

                            <!-- Form -->
                            <form class="form" enctype="multipart/form-data" method="post" action="<?php echo e(route('member.account.post')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <input name="first_name" value="<?php echo e(old('first_name')); ?>" type="text" placeholder="Enter First Name" >
                                    <span class="text-danger"><?php echo e($errors->first('first_name')); ?></span>
                                </div>
                                <div class="form-group">
                                    <input name="middle_name" value="<?php echo e(old('middle_name')); ?>" type="text" placeholder="Enter Middle Name" >
                                    <span class="text-danger"><?php echo e($errors->first('middle_name')); ?></span>
                                </div>
                                <div class="form-group">
                                    <input name="last_name" value="<?php echo e(old('last_name')); ?>" type="text" placeholder="Enter Last Name" >
                                    <span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
                                </div>
                                <div class="form-group">
                                    <input id="datepicker" name="date_of_birth" value="<?php echo e(old('date_of_birth')); ?>" type="text" placeholder="Enter Date of Birth" >
                                    <span class="text-danger"><?php echo e($errors->first('date_of_birth')); ?></span>
                                </div>
                                <div class="form-group">
                                    <input name="email" value="<?php echo e(old('email')); ?>" type="email" placeholder="Email Address" >
                                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                </div>
                                <div class="form-group">
                                    <input name="mobile_number" value="<?php echo e(old('mobile_number')); ?>" type="text" placeholder="Enter Mobile Number" >
                                    <span class="text-danger"><?php echo e($errors->first('mobile_number')); ?></span>
                                </div>
                                <div class="form-group">
                                    <textarea cols="2" name="contact_address" placeholder="Enter Contact Address" ><?php echo e(old('contact_address')); ?></textarea>
                                    <span class="text-danger"><?php echo e($errors->first('contact_address')); ?></span>
                                </div>
                                <div class="form-group">
                                    <input name="paper_title" value="<?php echo e(old('paper_title')); ?>" type="text" placeholder="Enter Paper Title" >
                                    <span class="text-danger"><?php echo e($errors->first('paper_title')); ?></span>
                                </div>

                                <div class="form-group">
                                    <textarea cols="2" name="author_details" placeholder="Enter Author Details" ><?php echo e(old('author_details')); ?></textarea>
                                    <span class="text-danger"><?php echo e($errors->first('author_details')); ?></span>
                                </div>

                                <div class="form-group">
                                    <input name="corresponding_author_email" value="<?php echo e(old('corresponding_author_email')); ?>" type="email" placeholder="Email Corresponding Author Email" >
                                    <span class="text-danger"><?php echo e($errors->first('corresponding_author_email')); ?></span>
                                </div>

                                <div class="form-group">
                                    <textarea cols="2" name="your_abstract" placeholder="Enter Your Abstract" ><?php echo e(old('your_abstract')); ?></textarea>
                                    <span class="text-danger"><?php echo e($errors->first('your_abstract')); ?></span>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" name="profile_image" value="<?php echo e(old('profile_image')); ?>" type="file">
                                    <span class="text-danger"><?php echo e($errors->first('profile_image')); ?></span>
                                </div>

                                <div class="form-group">
                                    <input name="password" value="<?php echo e(old('password')); ?>" type="password" placeholder="Enter Password" >
                                    <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                </div>
                                <div class="form-group">
                                    <input name="confirm_password" value="<?php echo e(old('confirm_password')); ?>" type="password" placeholder="Enter Confirm Password" >
                                    <span class="text-danger"><?php echo e($errors->first('confirm_password')); ?></span>
                                </div>

                                <div class="form-group">
                                    <div class="button">
                                        <button type="submit" class="btn primary">Register</button>
                                    </div>
                                </div>
                            </form>
                            <!--/ End Form -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP-7.4.2\htdocs\ju\resources\views/frontend/member/member_register.blade.php ENDPATH**/ ?>