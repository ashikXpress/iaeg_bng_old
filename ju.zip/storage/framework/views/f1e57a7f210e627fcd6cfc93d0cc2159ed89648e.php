<?php $__env->startSection('content'); ?>
    <div id="fb-root"></div>
    <!-- Start Breadcrumbs -->
    <section class="breadcrumbs overlay">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2>Event Details</h2>
                    <ul class="bread-list">
                        <li><a href="<?php echo e(route('home')); ?>">Home<i class="fa fa-angle-right"></i></a></li>
                        <li class="active"><a href="#">Event Details</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!--/ End Breadcrumbs -->

    <!-- Events -->
    <section class="events single section">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-12">
                    <div class="single-event">
                        <?php if($event->images->count() > 1): ?>
                        <div class="event-gallery">
                            <?php $__currentLoopData = $event->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-gallery">
                                <img src="<?php echo e(asset($item->image)); ?>" alt="#">
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php else: ?>
                         <img width="100%" height="auto" src="<?php echo e(asset($event->images[0]->image)); ?>" alt="#">
                        <?php endif; ?>
                        
                        <div class="event-content">
                            <div class="meta">
                                <strong>Start Date</strong>
                                <span><i class="fa fa-calendar"></i><?php echo e(date('d M Y',strtotime($event->start_date))); ?></span>
                                <span><i class="fa fa-clock-o"></i><?php echo e(date('h:m A',strtotime($event->start_date))); ?></span>

                                <strong>End Date</strong>
                                <span><i class="fa fa-calendar"></i> <?php echo e(date('d M Y',strtotime($event->end_date))); ?></span>
                                <span><i class="fa fa-clock-o"></i><?php echo e(date('h:m A',strtotime($event->end_date))); ?></span>


                            </div>
                            <h2><?php echo e($event->name); ?></h2>
                            <h4>Organizer: IAEG_Bangladesh National Group (International Association For Engineering Geology & The Environment_Bangladesh National Group) JU</h4>
                            <h4>Co-Organizer: Jahangirnagar University, KAGAWA University, GSB </h4>
                            <span><strong>Venue: <?php echo e($event->venue); ?></strong></span>
                            <span><strong>Session: <?php echo e($event->session); ?></strong></span>
                            <p><?php echo e($event->description); ?></p>
                            <div class="book-now">
                                <div class="button">
                                    <?php if($event->event_category_id==1): ?>
                                    <a href="<?php echo e(route('member.event.technical.join',$event->id)); ?>" class="btn">Apply for this event</a>
                                    <?php elseif($event->event_category_id==2): ?>
                                    <a href="<?php echo e(route('member.event.exhibition.join',$event->id)); ?>" class="btn">Apply for this event</a>
                                    <?php elseif($event->event_category_id==3): ?>
                                    <a href="<?php echo e(route('member.event.field.join',$event->id)); ?>" class="btn">Apply for this event</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="fb-comments" data-href="<?php echo e(url()->current()); ?>" data-numposts="10"></div>

                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-12">
                    <div class="learnedu-sidebar">
                        <!-- Categories -->
                        <div class="single-widget categories">
                            <h3 class="title">Archive</h3>
                            <ul>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Education Tips<span>2020</span></a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Education Tips<span>2021</span></a></li>
                                <li><a href="#"><i class="fa fa-angle-right"></i>Education Tips<span>2023</span></a></li>

                            </ul>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/ End Events -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('additionalJS'); ?>
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v5.0"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/iaegbng/public_html/resources/views/frontend/single_event.blade.php ENDPATH**/ ?>