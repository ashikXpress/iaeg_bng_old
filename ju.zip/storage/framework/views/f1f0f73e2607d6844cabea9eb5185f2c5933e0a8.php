<?php echo e($slot); ?>

<?php /**PATH D:\xampp\htdocs\ju\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>