<?php $__env->startSection('content'); ?>
    <!-- Start Breadcrumbs -->
    <section class="breadcrumbs overlay">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2><?php echo e($news_name->name); ?></h2>
                    <ul class="bread-list">
                        <li><a href="<?php echo e(route('home')); ?>">Home<i class="fa fa-angle-right"></i></a></li>
                        <li class="active"><a href="#"><?php echo e($news_name->name); ?></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!--/ End Breadcrumbs -->


    <!-- Courses -->
    <section class="courses archives section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title">
                        <h2>Your <span>Latest</span> News</h2>

                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-12">
                    <!-- Single Course -->
                    <div class="single-course">
                        <?php if($item->category_id==1): ?>
                        <div class="course-head overlay">
                            <img src="<?php echo e(asset($item->image_or_file)); ?>" alt="#">
                            <a href="<?php echo e(route('news.details',$item->id)); ?>" class="btn"><i class="fa fa-link"></i></a>
                        </div>
                        <?php endif; ?>
                        <div class="single-content">
                            <h4><a href="<?php echo e(route('news.details',$item->id)); ?>"><?php echo e($item->title); ?> <span><i class="fa fa-user"></i> Post by: <?php echo e($item->userName->name); ?></span></a></h4>

                            <p><?php echo e(\Illuminate\Support\Str::limit($item->description, 100, $end='...')); ?> <a
                                    href="<?php echo e(route('news.details',$item->id)); ?>" class="alert-link"> read more</a></p>
                        </div>
                        <div class="course-meta">
                            <div class="meta-left">
                                <span><i class="fa fa-clock-o"></i><?php echo e(date('d M Y',strtotime($item->upload_date))); ?></span>
                            </div>
                            <?php if($item->category_id===2): ?>
                            <span class="price"><a href="<?php echo e($item->image_or_file); ?>" target="_blank" style="color: #fff">File download <i class="fa fa-cloud-download"></i></a>
                        </span>
                            <?php endif; ?>

                        </div>
                    </div>
                    <!--/ End Single Course -->
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <div class="row">
                <div class="col-12">

                    <!-- Start Pagination -->
                    <div class="pagination-main">
                        <?php echo e($news->links()); ?>

                    </div>
                    <!--/ End Pagination -->
                </div>
            </div>
        </div>
    </section>
    <!--/ End Courses -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP-7.4.2\htdocs\ju\resources\views/frontend/news.blade.php ENDPATH**/ ?>