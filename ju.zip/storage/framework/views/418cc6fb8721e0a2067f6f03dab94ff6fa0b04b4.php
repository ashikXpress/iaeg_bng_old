<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="iq-card">
                <div class="iq-card-header d-flex justify-content-between">
                    <div class="iq-header-title">
                        <div class="card-title">
                            <div class="pull-left">
                                <h4>All Unapproved Member</h4>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="iq-card-body">
                    <?php if($message = Session::get('success')): ?>

                        <div class="alert alert-success">

                            <p><?php echo e($message); ?></p>

                        </div>

                    <?php endif; ?>
                    <table class="table">
                        <thead>
                        <tr>

                            <th>No</th>

                            <th>Image</th>
                            <th>Name</th>
                            <th>Type</th>
                            <th>Payment Info</th>
                            <th width="280px">Action</th>

                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td><?php echo e($loop->iteration); ?></td>

                                <td><img style="width: 80px;height: 80px;object-fit: contain" src="<?php echo e(asset($member->profile_image)); ?>" alt=""></td>

                                <td><?php echo e($member->first_name.' '.$member->middle_name.' '.$member->last_name); ?></td>
                                <td><?php echo e($member->memberType->name); ?></td>
                                <td>
                                    <button type="button" class="btn btn-primary btnView" data-id="<?php echo e($member->id); ?>">View</button>

                                </td>

                                <td>
                                    <a class="btn btn-success" href="<?php echo e(route('approved.member', $member->id)); ?>">Approved</a>

                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                    <?php echo e($members->links()); ?>

                </div>
            </div>
        </div>
    </div>

    <div class="modal fade bd-example-modal-lg" id="paymentModal" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Payment Details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Amount</th>
                                <th>Payment Method Name</th>
                                <th>TrxID</th>
                                <th>Bank Cheque</th>
                            </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td id="amount"></td>
                            <td id="paymentMethod"></td>
                            <td id="trxID"></td>
                            <td>
                                <a id="chequeAnchor" href="#" target="_blank"><img width="150" id="cheque" src="" alt="cheque"></a>
                            </td>
                        </tr>
                        </tbody>

                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('additionalJS'); ?>
    <script>
        $(function() {
            $('.btnView').click(function () {
                var id = $(this).data('id');

                $.ajax({
                    method: "GET",
                    url: "<?php echo e(route('member.payment.details')); ?>",
                    data: { id: id }
                }).done(function( data ) {
                    $('#paymentModal').modal('show');

                    $('#amount').html(data.amount);
                    $('#paymentMethod').html(data.payment_method);
                    $('#trxID').html(data.TrxID);

                    if (data.payment_method == 'bank') {
                        $('#cheque').attr('src', data.bank_cheque);
                        $('#chequeAnchor').attr('href', data.bank_cheque);
                        $('#chequeAnchor').show();
                    } else {
                        $('#chequeAnchor').hide();
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/iaegbng/public_html/resources/views/admin/member/unapproved_member.blade.php ENDPATH**/ ?>