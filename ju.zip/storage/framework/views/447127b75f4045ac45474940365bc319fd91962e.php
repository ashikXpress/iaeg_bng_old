<?php $__env->startSection('additionalCSS'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/lightbox2/css/lightbox.min.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Start Breadcrumbs -->
    <section class="breadcrumbs overlay">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2><?php echo e($gallery_category->name); ?> </h2>
                    <ul class="bread-list">
                        <li><a href="<?php echo e(route('home')); ?>">Home<i class="fa fa-angle-right"></i></a></li>
                        <li class="active"><a href="#"><?php echo e($gallery_category->name); ?></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!--/ End Breadcrumbs -->

    <!-- Events -->
    <section class="events archives section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title">
                        <h2>Yor Photo <span>Gallery</span></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-12">
                        <!-- Single Event -->
                        <div class="single-event">
                            <div class="head overlay">
                                <img src="<?php echo e(asset($item->image)); ?>" alt="#">
                                <a data-lightbox="album" data-title="<?php echo e($item->title); ?>" href="<?php echo e(asset($item->image)); ?>" class="btn"><i class="fa fa-link"></i></a>
                            </div>
                        </div>
                        <!--/ End Single Event -->
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="row">
                <div class="col-12">
                    <!-- Start Pagination -->
                    <div class="pagination-main">
                        <?php echo e($galleries->links()); ?>

                    </div>
                    <!--/ End Pagination -->
                </div>
            </div>
        </div>
    </section>
    <!--/ End Events -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('additionalJS'); ?>
    <script src="<?php echo e(asset('assets/frontend/lightbox2/js/lightbox.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP-7.4.2\htdocs\ju\resources\views/frontend/gallery.blade.php ENDPATH**/ ?>