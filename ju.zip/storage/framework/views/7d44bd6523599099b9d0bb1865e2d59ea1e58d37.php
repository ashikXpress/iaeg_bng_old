<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="iq-card">
                <div class="iq-card-header d-flex justify-content-between">
                    <div class="iq-header-title">
                        <div class="card-title">
                            <div class="pull-left">
                                <h4>All Slider</h4>
                            </div>
                            <div class="pull-right">

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-create')): ?>

                                    <a class="btn btn-primary" href="<?php echo e(route('slider.form')); ?>"> Create New Slider</a>

                                <?php endif; ?>

                            </div>
                        </div>

                    </div>
                </div>
                <div class="iq-card-body">
                    <?php if($message = Session::get('success')): ?>

                        <div class="alert alert-success">

                            <p><?php echo e($message); ?></p>

                        </div>

                    <?php endif; ?>
                    <table class="table">
                        <thead>
                        <tr>

                            <th>No</th>

                            <th>Image</th>
                            <th>Title</th>
                            <th>Sub Title</th>
                            <th>Sort</th>
                            <th width="280px">Action</th>

                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td><?php echo e($loop->iteration); ?></td>

                                <td><img width="150px" src="<?php echo e(asset($slider->image)); ?>" alt=""></td>

                                <td><?php echo e($slider->title); ?></td>
                                <td><?php echo e($slider->sub_title); ?></td>
                                <td><?php echo e($slider->sort); ?></td>
                                <td>
                                    <a class="btn btn-info" href="<?php echo e(route('slider.edit', $slider->id)); ?>">Edit</a>
                                    <a href="#" class="btn btn-danger" onclick="return checkDelete('<?php echo e(route('slider.delete',$slider->id)); ?>;')">Delete</a>

                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                    <?php echo e($sliders->links()); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/iaegbng/public_html/resources/views/admin/slider/all.blade.php ENDPATH**/ ?>