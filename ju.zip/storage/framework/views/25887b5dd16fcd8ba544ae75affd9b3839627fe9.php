<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php echo $__env->make('layouts.assets.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="iq-card">
                <div class="iq-card-header d-flex justify-content-between">
                    <div class="iq-header-title">
                        <h4 class="card-title">Join the Technical Event</h4>
                    </div>
                </div>
                <div class="iq-card-body">

                    <form action="<?php echo e(route('member.event.technical.submit')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="event_id" value="<?php echo e(request()->route('id')); ?>">
                        <div class="form-group">
                            <input type="text" value="<?php echo e(old('paper_title')); ?>" name="paper_title" placeholder="Enter Paper Title" class="form-control">
                        <span class="text text-danger"><?php echo e($errors->first('paper_title')); ?></span>
                        </div>
                        <div class="form-group">
                            <input type="text" value="<?php echo e(old('author_affiliation')); ?>" name="author_affiliation" placeholder="Enter Author Affiliation" class="form-control">
                            <span class="text text-danger"><?php echo e($errors->first('author_affiliation')); ?></span>

                        </div>
                        <div class="form-group">
                            <input type="text" value="<?php echo e(old('corresponding_email')); ?>" name="corresponding_email" placeholder="Enter Corresponding Email" class="form-control">
                            <span class="text text-danger"><?php echo e($errors->first('corresponding_email')); ?></span>

                        </div>
                        <div class="form-group" id="payment_method">
                            <select name="payment_method" class="form-control" id="payment_method_select">
                                <option value="">Select Payment Method</option>
                                <option value="bkash" <?php echo e(old('payment_method') == 'bkash' ? 'selected' : ''); ?>>Bkash</option>
                                <option value="rocket" <?php echo e(old('payment_method') == 'rocket' ? 'selected' : ''); ?>>Rocket</option>
                                <option value="bank" <?php echo e(old('payment_method') == 'bank' ? 'selected' : ''); ?>>Bank</option>
                            </select>
                            <span class="text text-danger"><?php echo e($errors->first('payment_method')); ?></span>
                        </div>
                        <div class="form-group">
                            <input type="text" name="amount" value="<?php echo e(old('amount')); ?>" placeholder="Enter Amount"  class="form-control">
                            <span class="text text-danger"><?php echo e($errors->first('amount')); ?></span>

                        </div>
                        <div class="form-group" id="trx_id">
                            <input type="text" name="TrxID" value="<?php echo e(old('TrxID')); ?>" placeholder="Enter TrxID"  class="form-control">
                            <span class="text text-danger"><?php echo e($errors->first('TrxID')); ?></span>

                        </div>
                        <div class="form-group" id="bank_cheque">
                            <div class="custom-file">
                                <input type="file" name="bank_cheque" class="custom-file-input" id="customFile">
                                <label class="custom-file-label" for="customFile">Choose Bank Cheque Image</label>
                                <span class="text text-danger"><?php echo e($errors->first('bank_cheque')); ?></span>

                            </div>
                        </div>

                        <div class="form-group">
                            <div class="custom-file">
                                <input type="file" name="abstract_doc_file" class="custom-file-input" id="customFile">
                                <label class="custom-file-label" for="customFile">Choose abstract doc file</label>
                            </div>
                            <span class="text text-danger"><?php echo e($errors->first('abstract_doc_file')); ?></span>

                        </div>
                        <div class="form-group">
                            <div class="custom-file">
                                <input type="file" name="presentation_ppt_file" class="custom-file-input" id="customFile">
                                <label class="custom-file-label" for="customFile">Choose presentation ppt file</label>
                            </div>
                            <span class="text text-danger"><?php echo e($errors->first('presentation_ppt_file')); ?></span>

                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <a href="<?php echo e(route('member.dashboard')); ?>" class="btn iq-bg-danger">cancel</a>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('additionalJS'); ?>
    <script>
        $("#payment_method").change(function () {
            var val = $('#payment_method_select').val();

            if (val == 'bkash' || val == 'rocket') {
                $('#trx_id').show();
                $('#bank_cheque').hide();
            } else if (val == 'bank') {
                $('#trx_id').hide();
                $('#bank_cheque').show();
            } else {
                $('#trx_id').hide();
                $('#bank_cheque').hide();
            }
        });

        $("#payment_method").trigger('change');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ju\resources\views/member/technical_event_join.blade.php ENDPATH**/ ?>