<?php $__env->startSection('content'); ?>
<div class="row">
    <?php echo $__env->make('layouts.assets.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

    <div class="row">
        <div class="col-md-12">
            <div class="iq-card">
                <div class="iq-card-header d-flex justify-content-between">
                    <div class="iq-header-title">
                        <div class="card-title">
                            <h4 class="pull-left">Admin Management </h4>
                            <div class="pull-right">

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-create')): ?>

                                    <a class="btn btn-primary" href="<?php echo e(route('users.create')); ?>"> Create New Admin</a>

                                <?php endif; ?>

                            </div>
                        </div>

                    </div>
                </div>
                <div class="iq-card-body">
                    <table class="table">
                        <thead>
                        <tr>

                            <th>No</th>

                            <th>Name</th>

                            <th>Email</th>

                            <th>Roles</th>

                            <th width="280px">Action</th>

                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td><?php echo e(++$i); ?></td>

                                <td><?php echo e($user->name); ?></td>

                                <td><?php echo e($user->email); ?></td>

                                <td>

                                    <?php if(!empty($user->getRoleNames())): ?>

                                        <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <label class="badge badge-success"><?php echo e($v); ?></label>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php endif; ?>

                                </td>

                                <td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-edit')): ?>
                                        <a class="btn btn-primary" href="<?php echo e(route('users.edit',$user->id)); ?>">Edit</a>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-delete')): ?>
                                        <?php echo Form::open(['method' => 'DELETE','route' => ['users.destroy', $user->id],'style'=>'display:inline']); ?>

                                            <?php if(Auth::user()->id!=$user->id): ?>
                                        <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                                            <?php endif; ?>
                                    <?php endif; ?>


                                    <?php echo Form::close(); ?>



                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                        <?php echo $data->render(); ?>

                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/iaegbng/public_html/resources/views/users/index.blade.php ENDPATH**/ ?>