<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php echo $__env->make('layouts.assets.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
   <div class="row">
       <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="col-sm-4">
           <div class="card iq-mb-3">
               <img src="<?php echo e(asset($event->images[0]->image)); ?>" class="card-img-top" alt="#">
               <div class="card-body">
                   <h5 class="card-title"><?php echo e($event->name); ?></h5>
                   <p class="mb-0"><strong>Start Date</strong> <i class="fa fa-calendar"></i> <?php echo e(date('d M Y',strtotime($event->start_date))); ?> <?php echo e(date('h:m A',strtotime($event->start_date))); ?></p>
                   <p class="mb-0"><strong>End Date</strong> <i class="fa fa-calendar"></i> <?php echo e(date('d M Y',strtotime($event->end_date))); ?> <?php echo e(date('h:m A',strtotime($event->end_date))); ?></p>
                   <h5>Venue: <?php echo e($event->venue); ?></h5>
                   <h6>Session: <?php echo e($event->session); ?></h6>
                       <a href="<?php echo e(route('member.event.details',$event->id)); ?>"><strong>read more</strong></a>

                   <p class="card-text mb-0"><small class="text-muted"><?php echo e($event->created_at->diffForHumans()); ?></small></p>
                  <?php
                      $member= Auth::guard('member')->user();

            $gold_check= DB::table('event_member')->where('event_id',$event->id)
                   ->where('member_id',$member->id)
                   ->where('exhibition_category','gold')
                   ->first();
              $platinum_check= DB::table('event_member')->where('event_id',$event->id)
                   ->where('member_id',$member->id)
                   ->where('exhibition_category','platinum')
                   ->first();
              $silver_check= DB::table('event_member')->where('event_id',$event->id)
                   ->where('member_id',$member->id)
                   ->where('exhibition_category','silver')
                   ->first();
              $bronze_check= DB::table('event_member')->where('event_id',$event->id)
                   ->where('member_id',$member->id)
                   ->where('exhibition_category','bronze')
                   ->first();
                  ?>
                   <h6>Already Join this event</h6>
                   <?php if($gold_check): ?>
                       <span class="badge badge-success">Golden</span>
                   <?php endif; ?>

                   <?php if($platinum_check): ?>
                       <span class="badge badge-success">platinum</span>
                   <?php endif; ?>

                   <?php if($silver_check): ?>
                       <span class="badge badge-success">Silver</span>
                   <?php endif; ?>

                   <?php if($bronze_check): ?>
                       <span class="badge badge-success">Bronze</span>
                   <?php endif; ?>

                   <?php if($gold_check && $platinum_check && $silver_check && $bronze_check): ?>
                       <button class="btn btn-warning btn-block mt-1">Already Participated all event</button>
                   <?php else: ?>
                       <a href="<?php echo e(route('member.event.exhibition.join',$event->id)); ?>" class="btn btn-primary btn-block mt-1">Join</a>

                   <?php endif; ?>


               </div>
           </div>
       </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ju\resources\views/member/exhibition_event_list.blade.php ENDPATH**/ ?>