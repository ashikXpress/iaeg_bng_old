<?php $__env->startSection('content'); ?>
    <!-- Start Breadcrumbs -->
    <section class="breadcrumbs overlay">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2>Member Login</h2>
                    <ul class="bread-list">
                        <li><a href="<?php echo e(route('home')); ?>">Home<i class="fa fa-angle-right"></i></a></li>
                        <li class="active"><a href="#">Login</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!--/ End Breadcrumbs -->
    <section id="contact" class="contact section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title">
                        <h2><span>Login</span> Information</h2>
                    </div>
                </div>
            </div>
            <div class="contact-head">

            </div>
            <div class="contact-bottom">
                <div class="row">
                    <div class="col-md-6 offset-3">
                        <?php if(session()->has('error')): ?>
                            <h5 class="alert alert-success"><?php echo e(session()->get('error')); ?></h5>
                        <?php endif; ?>
                        <div class="form-head">

                            <!-- Form -->
                            <form class="form" method="post" action="<?php echo e(route('member.login')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <input name="email" value="<?php echo e(old('email')); ?>" type="email" placeholder="Email Address" >
                                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                </div>


                                <div class="form-group">
                                    <input name="password" value="<?php echo e(old('password')); ?>" type="password" placeholder="Enter Password" >
                                    <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                </div>

                                    <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?> id="rememberme" class="filled-in chk-col-pink">
                                    <label for="rememberme">Remember Me</label>




                                <div class="form-group">
                                    <div class="button">
                                        <button type="submit" class="btn primary">Log in</button>
                                    </div>
                                </div>
                            </form>
                            <!--/ End Form -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP-7.4.2\htdocs\ju\resources\views/frontend/member/member_login.blade.php ENDPATH**/ ?>