<?php echo e($slot); ?>

<?php /**PATH D:\PHP-7.4.2\htdocs\ju\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>